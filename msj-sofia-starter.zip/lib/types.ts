export type Vehicle = {
  _id: string
  title: string
  slug: string
  price: number
  year?: number
  make?: string
  model?: string
  km?: number
  body?: string
  drivetrain?: string
  fuel?: string
  transmission?: string
  color?: string
  images?: string[]
  description?: string
  featured?: boolean
}

export type Service = {
  _id: string
  title: string
  slug: string
  excerpt?: string
  startingFrom?: number
  content?: any[]
  hero?: string
}
