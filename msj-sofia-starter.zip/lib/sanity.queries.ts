export const vehiclesQuery = `*[_type == "vehicle"]|order(featured desc, _createdAt desc){
  _id, title, "slug": slug.current, price, year, make, model, km, body, drivetrain, fuel, transmission, color,
  "images": images[].asset->url, description, featured
}`

export const vehicleBySlugQuery = `*[_type == "vehicle" && slug.current == $slug][0]{
  _id, title, "slug": slug.current, price, year, make, model, km, body, drivetrain, fuel, transmission, color,
  "images": images[].asset->url, description, featured
}`

export const servicesQuery = `*[_type == "service"]|order(title asc){
  _id, title, "slug": slug.current, excerpt, startingFrom, content, "hero": heroImage.asset->url
}`
