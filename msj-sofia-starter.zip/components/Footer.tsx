export default function Footer() {
  return (
    <footer className="border-t mt-16">
      <div className="container py-8 text-sm text-neutral-600">
        © {new Date().getFullYear()} MSJ + Sofia. Tous droits réservés.
      </div>
    </footer>
  )
}
