type Props = { title: string; subtitle?: string; variant?: 'msj' | 'sofia' | 'default'; ctas?: React.ReactNode }
export default function Hero({ title, subtitle, variant='default', ctas }: Props) {
  const base = variant === 'msj' ? 'bg-msj-primary' : variant === 'sofia' ? 'bg-sofia-primary' : 'bg-neutral-900'
  return (
    <section className={`${base} text-white`}>
      <div className="container py-16">
        <h1 className="text-3xl md:text-5xl font-bold">{title}</h1>
        {subtitle && <p className="mt-3 text-lg opacity-90">{subtitle}</p>}
        {ctas && <div className="mt-6 flex gap-3">{ctas}</div>}
      </div>
    </section>
  )
}
