import Image from 'next/image'
import Link from 'next/link'
import { Vehicle } from '@/lib/types'

export default function VehicleCard({ v }: { v: Vehicle }) {
  const img = v.images?.[0]
  return (
    <div className="border rounded-xl overflow-hidden">
      <Link href={`/sofia/vehicle/${v.slug}`}>
        <div className="relative w-full h-48 bg-neutral-100">
          {img && <Image src={img} alt={v.title} fill className="object-cover" />}
        </div>
        <div className="p-4">
          <div className="font-semibold">{v.title}</div>
          <div className="text-sm opacity-80">{[v.year, v.make, v.model].filter(Boolean).join(' ')}</div>
          <div className="mt-2 font-bold">${"{"}v.price.toLocaleString(){"}"}</div>
        </div>
      </Link>
    </div>
  )
}
