'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export default function Header() {
  const pathname = usePathname()
  return (
    <header className="border-b">
      <div className="container py-4 flex items-center justify-between gap-4">
        <Link href="/" className="font-bold text-lg">MSJ + Sofia</Link>
        <nav className="flex items-center gap-4">
          <Link href="/msj" className={linkCls(pathname?.startsWith('/msj'))}>MSJ</Link>
          <Link href="/sofia" className={linkCls(pathname?.startsWith('/sofia'))}>Sofia Auto</Link>
          <Link href="/studio" className="text-sm opacity-70 hover:opacity-100">CMS</Link>
        </nav>
      </div>
    </header>
  )
}

function linkCls(active?: boolean) {
  return `px-3 py-1 rounded ${active ? 'bg-neutral-900 text-white' : 'hover:bg-neutral-100'}`
}
