import { defineField, defineType } from 'sanity'

export default defineType({
  name: 'siteSettings',
  title: 'Site Settings',
  type: 'document',
  fields: [
    defineField({ name: 'phoneMsj', type: 'string' }),
    defineField({ name: 'phoneSofia', type: 'string' }),
    defineField({ name: 'address', type: 'string' }),
    defineField({ name: 'hours', type: 'string' }),
    defineField({ name: 'bookingUrl', type: 'url', description: 'MSJ booking (Calendly/TidyCal)' }),
    defineField({ name: 'languages', type: 'array', of: [{ type: 'string' }], initialValue: ['fr','en'] }),
  ],
})
