import { defineField, defineType } from 'sanity'

export default defineType({
  name: 'vehicle',
  title: 'Vehicle',
  type: 'document',
  fields: [
    defineField({ name: 'title', type: 'string', validation: r => r.required() }),
    defineField({ name: 'slug', type: 'slug', options: { source: 'title', maxLength: 96 }, validation: r => r.required() }),
    defineField({ name: 'price', type: 'number', validation: r => r.required().positive() }),
    defineField({ name: 'year', type: 'number' }),
    defineField({ name: 'make', type: 'string' }),
    defineField({ name: 'model', type: 'string' }),
    defineField({ name: 'km', type: 'number' }),
    defineField({ name: 'body', type: 'string' }),
    defineField({ name: 'drivetrain', type: 'string' }),
    defineField({ name: 'fuel', type: 'string' }),
    defineField({ name: 'transmission', type: 'string' }),
    defineField({ name: 'color', type: 'string' }),
    defineField({ name: 'images', type: 'array', of: [{ type: 'image' }], options: { layout: 'grid' } }),
    defineField({ name: 'description', type: 'text' }),
    defineField({ name: 'featured', type: 'boolean', initialValue: false }),
  ],
  preview: { select: { title: 'title', media: 'images.0' } }
})
