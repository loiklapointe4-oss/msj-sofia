import vehicle from './vehicle'
import service from './service'
import siteSettings from './siteSettings'

export const schemaTypes = [vehicle, service, siteSettings]
