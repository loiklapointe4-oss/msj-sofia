# MSJ + Sofia Starter (Next.js + Tailwind + Sanity)

A 2‑in‑1 gateway site for **MÉCANIQUE ST‑JANVIER (MSJ)** and **SOFIA AUTO**.

## Stack
- Next.js (App Router) + TypeScript + Tailwind
- Sanity (embedded Studio at `/studio`)
- Basic schemas: `vehicle`, `service`, `siteSettings`

## Quick Start

1. **Install**
   ```bash
   pnpm i # or npm i or yarn
   ```

2. **Create a Sanity project** (if you don’t have one):
   - Go to https://www.sanity.io/manage and create a project + dataset `production`

3. **Configure env**
   Copy `.env.example` to `.env.local` and set:
   ```env
   NEXT_PUBLIC_SANITY_PROJECT_ID=your_project_id
   NEXT_PUBLIC_SANITY_DATASET=production
   ```

4. **Run**
   ```bash
   pnpm dev
   # Site on http://localhost:3000
   # Studio on http://localhost:3000/studio
   ```

5. **Add content**
   - In Studio → add a few **Service** docs for MSJ
   - Add **Vehicle** docs with images for Sofia Auto

## Routes

- `/` — Gateway landing with two CTAs
- `/msj` — MSJ services overview (pulls from Sanity)
- `/sofia` — Sofia Auto landing
- `/sofia/inventory` — Vehicles grid (from Sanity)
- `/sofia/vehicle/[slug]` — Vehicle details
- `/studio` — Sanity Studio

## Deployment (Vercel)

1. Push this repo to GitHub.
2. Import into Vercel.
3. Set **Environment Variables** in Vercel:
   - `NEXT_PUBLIC_SANITY_PROJECT_ID`
   - `NEXT_PUBLIC_SANITY_DATASET`
4. Deploy.

## Next Steps

- Hook up **booking URL** (Calendly/TidyCal) in `siteSettings` and render in `/msj`.
- Add **Carfax** link field to `vehicle` schema.
- Add **inventory filters** (client-side) by make/model/year/price.
- Add **EN translations** (next-intl) if needed.
- Connect forms (test drive / finance) to your email/CRM.

---

Built for fast shipping. Customize colors in `tailwind.config.ts`.
